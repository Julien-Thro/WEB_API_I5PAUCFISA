document.addEventListener('DOMContentLoaded', function() {
  console.log('Chargement de la page "Villes" terminé');
});

/* ------------------------------------------- */

/*
document.getElementById('bouton-ok').addEventListener('click', function() {

  var city = document.querySelector('input[name="city"]').value;
  var xhr = new XMLHttpRequest();

  xhr.open('POST', 'weather.php', true);
  xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
  
  xhr.onload = function() {
    if (this.status == 200) {
    
      var data = JSON.parse(this.responseText);
      var src_img_meteo = 'https://openweathermap.org/img/wn/';
      var src_img_temp = 'img/villes-icons/temp/';
      var chiffre_centaines = Math.floor(data.id / 100);
      var chiffre_temp = Math.floor(data.temp / 10);

      switch (chiffre_centaines) {
        case 2: src_img_meteo = src_img_meteo.concat('11d@2x.png'); break;
        case 3: src_img_meteo = src_img_meteo.concat('09d@2x.png'); break;
        case 5:
          switch (data.id) {
            case 500: src_img_meteo = src_img_meteo.concat('10d@2x.png'); break;
            case 501: src_img_meteo = src_img_meteo.concat('10d@2x.png'); break;
            case 502: src_img_meteo = src_img_meteo.concat('10d@2x.png'); break;
            case 503: src_img_meteo = src_img_meteo.concat('10d@2x.png'); break;
            case 504: src_img_meteo = src_img_meteo.concat('10d@2x.png'); break;
            case 511: src_img_meteo = src_img_meteo.concat('13d@2x.png'); break;
            case 520: src_img_meteo = src_img_meteo.concat('09d@2x.png'); break;
            case 521: src_img_meteo = src_img_meteo.concat('09d@2x.png'); break;
            case 522: src_img_meteo = src_img_meteo.concat('09d@2x.png'); break;
            case 531: src_img_meteo = src_img_meteo.concat('09d@2x.png'); break;
            default: console.log("Erreur sur meteo_id"); break;
          }
          break;
        case 6: src_img_meteo = src_img_meteo.concat('13d@2x.png'); break;
        case 7: src_img_meteo = src_img_meteo.concat('50d@2x.png'); break;
        case 8:
          switch (data.id) {
            case 800: src_img_meteo = src_img_meteo.concat('01d@2x.png'); break;
            case 801: src_img_meteo = src_img_meteo.concat('02d@2x.png'); break;
            case 802: src_img_meteo = src_img_meteo.concat('03d@2x.png'); break;
            case 803: src_img_meteo = src_img_meteo.concat('04d@2x.png'); break;
            case 804: src_img_meteo = src_img_meteo.concat('04d@2x.png'); break;
            default: console.log("Erreur sur meteo_id"); break;
          }
          break;
        default: console.log("Erreur sur chiffre_centaines"); break;
      }

      if (chiffre_temp <= 0) {
        src_img_temp = src_img_temp.concat('1.png');
      } else {
        switch (chiffre_temp) {
          case 1: src_img_temp = src_img_temp.concat('2.png'); break;
          case 2: src_img_temp = src_img_temp.concat('3.png'); break;
          case 3: src_img_temp = src_img_temp.concat('4.png'); break;
          case 4: src_img_temp = src_img_temp.concat('5.png'); break;
          default: src_img_temp = src_img_temp.concat('6.png'); break;
        }
      }
      */

/*
document.getElementById('villes-temperature').innerHTML = data.temp + '°C';
document.getElementById('villes-latitude').innerHTML = data.lat;
document.getElementById('villes-longitude').innerHTML = data.long;
document.getElementById('villes-meteo').innerHTML = data.wheather;
document.getElementById('villes-vent').innerHTML = data.vent;
document.getElementById('villes-humidite').innerHTML = data.hum;
 
} else {
alert('Erreur lors de la récupération des données');
}
*/

/*
let map;

if (map) { map.remove(); }

map = L.map('map').setView([41, 12], 7);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap contributors' }).addTo(map);
L.marker([41, 12]).addTo(map);
*/

//xhr.send('city=' + encodeURIComponent(city));

function getWindDirection(degrees) {
  const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  const index = Math.round(degrees / 45) % 8;
  return directions[index];
}