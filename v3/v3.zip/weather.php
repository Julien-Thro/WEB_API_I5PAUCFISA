<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['city'])) {
    $apiKey = '1756f1e19a1c73cb1e3d481af41f5392';
    $city = trim($_POST['city']);
    $url = "https://api.openweathermap.org/data/2.5/weather?q=" . urlencode($city) . "&appid=" . $apiKey . "&units=metric";

    $response = file_get_contents($url);
    $data = json_decode($response, true);

    if ($data['cod'] == 200) {
        echo json_encode([
            'temp' => $data['main']['temp'],
            'lat' => $data['coord']['lat'],
            'lon' => $data['coord']['lon'],
            'id' => $data['weather'][0]['id'],
            'deg' => $data['wind']['deg'],
            'speed' => $data['wind']['speed']
        ]);
    } else {
        echo json_encode(['error' => 'Erreur lors de la récupération des données météo']);
    }
    exit;
}
?>
